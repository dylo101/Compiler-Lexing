
'' // char too short

'abcd' // char too long


