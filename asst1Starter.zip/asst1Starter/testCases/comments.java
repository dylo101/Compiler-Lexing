// there is one token in this file: a '*'

// abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ

// `~!@#$%^&*()_-+=
// {}[]|;':,./<>? 

// 0123456789

// \  "


/*abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ

     `~!@#$%^&*()_-+=*/

/*/*/*/*/*/
    
/*
 {}[]|;':,./<>? 

 0123456789

 \  "
*/


