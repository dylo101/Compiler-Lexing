/*   comment number starts on this line

     /*  <---warning would be here

*/

// the following should be a '*' and a '/' token

*/



