
"a\n" "b\t" "c\r" "d\"" "e\'" "f\f" "g\\"

"\na" "\tb" "\rc" "\"d" "\'e" "\ff" "\\g"    

