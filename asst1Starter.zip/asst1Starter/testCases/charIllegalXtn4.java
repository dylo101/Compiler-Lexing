     // illegal character
	     
  @ // illegal character

 w // an identifier token      

