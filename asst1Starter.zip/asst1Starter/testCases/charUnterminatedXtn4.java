

'a'  // this character ends

'b
// the above character does not end    


