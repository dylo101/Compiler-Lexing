

" this string ends "

" this string does not

"... and this string ends"    
