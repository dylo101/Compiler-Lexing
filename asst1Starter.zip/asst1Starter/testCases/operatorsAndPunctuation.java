  !  !=  %  &&  * ( ) -     +   /*
				this is a comment


 */
==     =   ||   }   {    ;   :  ++   --
// this is a comment
[     ]  < <=    >=   >   ,    .    /



