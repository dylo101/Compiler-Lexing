/*   this comment ends

 */

abc // a token we recognize

/* this comment does not end


    
