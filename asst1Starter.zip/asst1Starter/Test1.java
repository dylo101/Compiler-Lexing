class {
  void () {
    boolean  = new ().(null);
  }
}

class  {
  boolean ([] ) {
    int  = 4;
    int  = +215;
  }
}


class Main {
	  void main() {
	    boolean b = new Blizzard().run(null);
	  }
	}

	class Blizzard {
	  boolean run(String[] x) {
	    int a = 4;
	    int b = a+215;
	  }
	}

